package bgu.atd.a1;


public interface callback {
	public void call();
}
